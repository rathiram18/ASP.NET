﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Ramachandran_Project.Startup))]
namespace Ramachandran_Project
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
